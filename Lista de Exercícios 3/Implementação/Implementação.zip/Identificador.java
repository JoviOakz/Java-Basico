public interface Identificador {
    int getId();
}